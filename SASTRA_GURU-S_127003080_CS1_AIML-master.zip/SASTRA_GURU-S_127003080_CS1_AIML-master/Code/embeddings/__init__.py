"""Embedding generation modules."""
