"""Architecture-aware chunking modules."""
